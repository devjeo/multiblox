# Changelog

## Unreleased

### Added
- **Current tab and protected servers.** New **Current** tab (Player | Finder | Private | Hopper | History | Current) that lists only the servers where your accounts are in right now: Game, Server ID, Accounts. They stay in History too (green, at the top). Click one to pick it as the join target, same as History; the two tabs share one pick. A server with an account in it **can not be cleared**: *Clear all* in History skips it (the confirm says how many are kept, and the button greys out when only online servers are left), *Remove from history* refuses it, and *Clear this account's history* keeps that account's visit to the server it is in now. Once the account leaves, the server is a normal row again. New `current_servers_panel.py`; `ServerHistory.clear/remove(keep=...)`, `AccountHistory.clear(keep=...)`.
- **See where each account is right now.** The History tab marks servers that have an account in them: they are listed first, in green, with *Online now* in the When column and the online account names (earlier visitors show as "+N earlier"). A server stays listed while an account is in it, even if you removed it from the history. The tab also says how many accounts are online and updates by itself when an account joins, leaves or teleports. In the accounts table, the *Server . Last game* column starts with the same short server ID for each running account, so you can match an account to its server from either side. Only servers Roblox's presence has confirmed count as online. `RejoinManager.live_servers()`.
- **Faster History.** Where an account is used to be checked once every 45 s, one account after another, so a new join took up to a minute to show. Now a client that is not yet confirmed in a server is asked every 5 s (starting 15 s after the launch, up to 5 minutes), a confirmed one every 15 s, so joins, teleports and leaves show in about 5-20 s. The checks run in the background (a slow answer no longer delays other accounts), only update the location, and never count as a disconnect: rejoin detection still uses the 45 s check (`presencePollSeconds`) exactly as before. Before the first confirmed answer, an early check that still shows the server the account was in before this join is ignored. If Roblox cannot be asked (rate limit, network) the checks wait 30 s.
- Wrapping texts in the left panel re-wrap when the window is resized (`ui_style.autowrap`).
- **All join tools in one left panel.** The left column is now a single notebook: **Player | Finder | Private | Hopper | History**. The Find server... button and its window are gone. The server history card under the accounts list moved into the History tab.
- **Launch normally.** A picked player or history server no longer hijacks Launch selected: the pick is dropped by itself once a join has started, clicking the picked row again (or Esc, or Clear player) drops it, and a **Launch normally** button and right-click item launch the highlighted accounts into the Game box.
- **Resizable window that stays put.** The main window can be resized and maximized again (minimum 880x560). Buttons, search and tab switches never resize it; only dragging does. Table column borders still cannot be dragged.
- **Per-account server history** (right-click an account > Server history...): every server that account got into with date and time, last 50 each, and a button to send the selected accounts there. **Join same server as** (right-click submenu): the selected accounts join the exact server another of your accounts is in right now, read with that account's own login, so no friend-join and no privacy changes are needed. New `account_history.py`, `account_history_dialog.py`.
- **Join panel** (new left column; the window is now three columns: Join panel | accounts | game and actions). Look up a player or pick one from **History** (the last 30 players you looked up or joined, newest first) or **Online friends**. Picking a player only selects them; **Launch selected** (also Enter, double-click and right-click Launch) becomes "Join <name>" and joins their server. It replaces the Join friend and Join user tabs of the Find server window. New `join_panel.py` and `join_history.py`.
- **Stay and wait if the server is full** (Join panel checkbox, on by default). Player joins and joins from the Server history no longer close the account after 75 s. The Roblox client is left open and untouched for as long as it takes to get into that exact server: no timeout, nothing closed or relaunched, and the log/presence "disconnected" checks are skipped until it is in. New account status "Waiting to get in...". Stop ends the wait. If the client process itself exits, the same server (never another) is launched again after 20 s, without the 5-attempts limit. Waiting does not survive an app restart. Server finder joins keep the 75 s rule. `RejoinManager.launch/hop(patient=...)`.
- **Server history** (card under the accounts list). Every server any account got into, all games mixed, newest first, with Game, Server ID, When and Accounts columns. Recorded from Roblox's presence, so only confirmed joins are listed (random joins and teleports included). Click a row to pick it; the Join button then sends every selected account to that exact server. New `server_history.py`, `server_history_panel.py`, and `RejoinManager(on_server_fn=...)`.
- **Joining closes a running account first.** An account that is already playing is closed completely and relaunched into the exact server (job ID) of the player, or of the server clicked in Server finder, instead of being skipped with "use Stop first". An account already in that server is left alone, and the confirm dialog (when enabled) lists the accounts that will be closed. `RejoinManager.hop()` takes `strict`.

- **Server hopper** (Find server... > Server hopper). Moves the selected accounts to a new public server every N minutes, or once with *Hop now*. A hop closes the account's game completely, waits until the process is gone, and only then starts the new one, so an account never runs two clients. The new server is chosen before anything is closed (no server with room = the account stays put), a server is not handed out twice in a row, and accounts hopping in the same game are spread over different servers. Stopping an account ends its hopping; accounts in a private server are skipped. New `server_hopper.py` and `RejoinManager.hop()`.
- Settings: `serverCacheSeconds` (120), `hopIntervalMinutes`, `hopMode`, `hopMinPlayers`.

### Removed
- Looking up a player no longer saves them to the player History: only a player you actually join is remembered.
- The Find server... window (its tabs now live in the left panel).
- Group and Note columns, the group filter, Launch group, and the right-click Set group / Edit note / group default items are gone from the main window. Saved values are kept; the console and scheduler still understand them.

### Changed
- **Server finder: click to join.** Clicking a server in the list joins it right away with the accounts selected in the main window (strict: an account that does not get into that exact server is closed, never sent elsewhere). A full server is refused, and the header row and the auto-selected best row never join. The old button is now *Only fill Server box*. A new *History* column marks servers a hop or a join already used.
- **Server hopper: history, no schedule by default.** Hop now is the main action. Every server hopped into or joined from the Server finder goes into a per-game history (newest first, up to 100, shown in the tab, with *Clear history*), and a hop never goes back into it. It picks from the same cached list the finder searched. When every listed server has been visited only the newest few stay blocked (at most half the list), so hopping never stalls and never bounces straight back. The timer is now an *Auto-hop every N minutes* checkbox, off by default; unchecking it cancels all timers, and it unchecks itself when every timer has ended.
- **Window sizes.** The main window opens at 60% of the screen's width and height (rounded down to the 16 px grid; small screens get at least 880x560, but never more than the screen). The Join tools window is smaller (52% x 58% of the screen) and its help and status texts re-wrap to its width. Every window is resizable now: Settings (was fixed in width) and the schedule rule editor (was fixed in both) can be resized too, and the rule editor will not shrink below its form.
- **Server lists are cached for the session** (`server_finder.ServerCache`). Find reuses a game's list for 2 minutes instead of asking Roblox again, a new *Refresh* button forces a new list (no more than once every 10 s), and after an HTTP 429 no further requests are made for 90 s; during that time, or if Roblox fails, the last list is shown and marked as older. Diagnostics shows the request count and any cooldown.

### Fixed
- The lists in Server finder, Join friend, Private server and the game search were created before the frame that holds them and then packed into it, which put them under that frame in Tk's stacking order and made them invisible. They are now drawn on top.

### Changed
- **Game picker.** The Game box in the main window and the Private server tab now share one picker: type or pick a saved game, paste a place ID or roblox.com link, or type a name and press Search (or Enter) to look the game up on Roblox. Results show the game's picture, players, rating and creator; picking one fills the box and, by default, saves it to your games (a game you already saved keeps your name). Emoji in game names are dropped so they cannot break Tk. New `game_search.py` and `game_picker.py`.
- **Private server tab** (Find server...): pick a game (saved game, place ID or link), press Load, and see the private servers of the selected account and of its friends, with a Mine / Friends filter. Select one and press Arm. There is no paste-a-launch-link box any more: nothing needs to be copied from the browser. New `private_servers.py`; Diagnostics shows the last load.

## 2.0.0 - 2026-10-16

### Added
- **Account groups and notes.** Group and note columns, a group filter, "Launch group", per-group default game, `group:<name>` in the console.
- **Notifications.** Discord webhook and system tray alerts for disconnects, give-ups and expired cookies, with a per-event cooldown and a Test button. The webhook URL is stored DPAPI-encrypted in `secrets.json` and is redacted from logs and reports.
- **Join tools** (Find server...): server finder (emptiest, fullest, best, minimum players), friend join, and private-server links (experimental).
- **Resource saver.** Normal, Low and Minimum client-flag profiles applied before launch, with an exact-bytes "Restore original".
- **Window layout.** Tile, minimize and restore all client windows on a chosen monitor, with optional auto-tile for new clients.
- **Scheduler.** Start and stop rules for an account or group on chosen days and times. A run missed while the app was closed or the PC slept fires once if it is inside the missed-run window (default 30 minutes).
- Diagnostics checks for every new feature; the report header now shows the app version.
- Shared infrastructure: `settings.py`, `secrets_store.py`, `net.py` (retries and CSRF handshake), `workers.py`, `jsonio.py`.
- `RobloxAccountManager.spec` and build instructions for a one-file Windows exe.
- `installer.iss`: an Inno Setup script that produces a single Setup installer exe.
- MIT `LICENSE`, also shown as a page in the installer.

### Changed
- `multi_instance.log` and `rejoin_debug.log` now live in `%APPDATA%\RobloxAccountManager\` instead of next to the scripts, so they work from a packaged exe.
- Settings moved out of `gui.py` into `settings.py` (same behaviour).

### Notes
- Existing `accounts.json` files open unchanged; the new `group` and `note` keys are added on the next save and ignored by older versions.
- Private servers and the resource-saver flags depend on Roblox behaviour that Roblox can change. Both are marked experimental or unverified in the app.

## 1.0.0
- Initial release: multi-instance, launching, auto-rejoin, crash recovery, diagnostics.